package org.openrewrite;

public class ExampleRecipe extends Recipe {

    @Override
    public String getDisplayName() {
        return "Example Recipe";
    }

    @Override
    public String getDescription() {
        return "This is a recipe.";
    }
}
